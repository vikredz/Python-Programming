'''
Vikramaditya Reddy Varkala
Z1973679
Assignment 5
This package contains data,generation,compare,modules for Pokemon data and operations on the data
'''
pass