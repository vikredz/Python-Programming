import data


def pokemon_stats(name):
#retrive data from data module
    pokemon_data = data.get_data()
    for pokemon in pokemon_data:
#checks if given input name is equal to pokemon name 
#.lower() makes given input to lower case so comparision is not case sensitive
        if pokemon['name'].lower()==name.lower():
            return pokemon
    return None

#combat power 
def combat(pokemon):
    attack=2*round((pokemon['attack']**0.5)*(pokemon['sp_attack']**0.5)+(pokemon['speed']**0.5))
    defense=2*round((pokemon['defense']**0.5)*(pokemon['sp_defense']**0.5)+(pokemon['speed']**0.5))
    stamina=2*pokemon['hp']
    max_cp=(attack + 15)*((defense + 15)**0.5)*((stamina+15)**0.5)*0.7903001**2/10
    return max_cp

#DRY Principle
def attack_diff(p1,p2):
    return p1['attack']-p2['attack']


def defense_diff(p1,p2):
    return p1['defense']-p2['defense']


def hp_diff(p1, p2):
    return p1['hp']-p2['hp']


def combat_power_diff(n1,n2):
    p1=pokemon_stats(n1)
    p2=pokemon_stats(n2)

#returns none if p1 or p2 is empty
    if p1 is None or p2 is None:
        return None
    
    else:
        cp1=combat(p1)
        cp2=combat(p2)
        cp=cp1-cp2
        
        return cp