import os
import json
from urllib.request import urlretrieve
from urllib.request import urlopen

data=[]

def get_data():
    url = "https://faculty.cs.niu.edu/~dakoop/cs503-2023sp/a5/pokemon.json"
    local_fname = "pokemon.json"
    
    global data
    
    if not os.path.exists(local_fname):
        urlretrieve(url, local_fname)
        
    if(data==[]):
        data= json.load(open(local_fname)) 
  
    return (data)   