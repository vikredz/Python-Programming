import data
import collections

def generation_types(x):
#retrive data from data module
    gen_data=data.get_data()
    count=collections.Counter()
    for pokemon in gen_data:
#checks if given input x is equal to pokemon generation
        if pokemon['generation']==x:
            count[pokemon['primary_type']]=count[pokemon['primary_type']]+1
#returning as dictionary
    return dict(count)

def generation_ranges(x):
    gen_data=data.get_data()
    
# empty lists to store values of hp,attack,defence
    hitpoints=[]
    attack=[]
    defense=[]
    
    for pokemon in gen_data:
        if pokemon['generation'] == x:
#adding values to the respective empty lists.

            hitpoints.append(pokemon['hp'])
            attack.append(pokemon['attack'])
            defense.append(pokemon['defense'])
#dictionary stats to store minimum and maximum values of hp,attack and defence.
    stats={'hp':(min(hitpoints),max(hitpoints)),'attack':(min(attack),max(attack)),'defense':(min(defense),max(defense))}
    return stats
# References:https://docs.python.org/3/library/collections.html#collections.Counter