'''
Vikramaditya Reddy Varkala
Z1973679
Assignment 5
'''

import sys
from pokemon_analysis.generation import generation_ranges
from pokemon_analysis.compare import combat_power_diff

#importing generatation_ranges and combat_power_diff functions from generationa and compare modules respectively
#creating a seperate usage method 
def usage():
    
    print("Usage: python -m pokemon_analysis [generation <num> | compare <name1> <name2>]")
    print("generation <num>: for generation number")
    print("compare <name1><name2>: to compare combat power of two Pokémon")

#usage method can be  called in case of requirement of instructions
#reference:https://www.geeksforgeeks.org/__name__-a-special-variable-in-python/ 

if __name__=='__main__':

#generation subcommand
#Reference cell 23:https://nbviewer.org/url/faculty.cs.niu.edu/~dakoop/cs503-2023sp/notebooks/lecture12.ipynb
    if len(sys.argv)!=3:
    usage()
    else:
        generation = sys.argv[2]
        if not generation.isnumeric():
            usage()
        else:
            generation=int(generation)
            stats=generation_stats.generation_ranges(generation)
            print(f"Generation {generation}:")
            for key,value in stats.items():
                print(f"{key}:{value}")
 

 #compare subcommand           
    elif len(sys.argv)==4 and sys.argv[1]=='compare':
        pokemon1=sys.argv[2]
        pokemon2=sys.argv[3]
#using combat_power_diff from compare module     
        cp_diff=compare.combat_power_diff(pokemon1, pokemon2)
        if cp_diff is None:
            print("One or more of the Pokémon were not found.")
            usage()
            
        else:
 # displaying + or - appropriately for the compare subcommand

            if cp_diff>0:
                print(f"{pokemon1} has +{cp_diff} combat power than {pokemon2}")
            else:
                print(f"{pokemon1} has -{cp_diff} combat power than {pokemon2}")
                usage()
            
              
    # References:https://nbviewer.org/url/faculty.cs.niu.edu/~dakoop/cs503-2023sp/notebooks/lecture12.ipynb
# https://docs.python.org/3/library/__main__.html